import React from 'react'

const Contact = () => {
  return (
    <div className=' contact text-center'>
     <h1 className='fw-bold display-1'>Contact Us</h1>
    </div>
  )
}

export default Contact