import React from 'react'

const About = () => {
  return (
    <div>
      <h1 className='fw-bold display-1 text-center' >About our Store</h1>

    {/* <!-- About Us Section --> */}
    <section class="container py-5">
        <div class="row">
            <div class="aboutf">
                <h2>About Our Store</h2>
                <p>Welcome to our online store! We offer a wide variety of products designed to meet all of your needs. Our
                    mission is to provide high-quality products at affordable prices while ensuring a seamless shopping
                    experience for all our customers.</p>
                <p>Founded in [Year], our store has been committed to bringing the best shopping experience to you. Our
                    dedicated team works tirelessly to bring you the latest and greatest products.</p>
            </div>
            
        </div>
    </section>

    {/* <!-- Our Values Section --> */}
    <section class="bg-light py-5">
        <div class="container">
            <h3 class="text-center mb-4">Our Values</h3>
            <div class="row text-center">
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Quality</h5>
                            <p class="card-text">We prioritize offering high-quality products to ensure your satisfaction.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Customer Service</h5>
                            <p class="card-text">Our team is always here to assist you with any questions or concerns.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Affordability</h5>
                            <p class="card-text">We strive to offer products at prices that are accessible to everyone.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {/* <!-- Footer Section --> */}
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p>&copy; 2024 Store. All rights reserved.</p>
        </div>
    </footer>
    </div>
  )
}

export default About