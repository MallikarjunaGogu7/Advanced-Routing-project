import React from 'react'

const Home = () => {
  return (
    <div className='home text-center'>
       <h1 className='fw-bold display-1' >Welcome Home</h1>
    </div>
  )
}

export default Home